-- Create sequence 
create sequence JD_MESSAGE_TAB_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 7937481
increment by 1
cache 20;
