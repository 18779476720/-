-- Create sequence 
create sequence ITF_INTERFACE_API_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 1066
increment by 1
cache 20;
