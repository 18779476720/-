-- Create sequence 
create sequence JD_ORDER_CHECKED_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 21
increment by 1
cache 20;
