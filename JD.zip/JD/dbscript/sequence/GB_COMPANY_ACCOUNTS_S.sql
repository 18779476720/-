-- Create sequence 
create sequence GB_COMPANY_ACCOUNTS_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;
