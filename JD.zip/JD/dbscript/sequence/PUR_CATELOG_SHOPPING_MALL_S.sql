create sequence PUR_CATELOG_SHOPPING_MALL_S;
