-- Create sequence 
create sequence JD_MESSAGE_HANDLE_HISTORY_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 1724841
increment by 1
cache 20;
