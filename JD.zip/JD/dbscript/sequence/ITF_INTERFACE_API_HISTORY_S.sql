-- Modify the last number 
alter sequence ITF_INTERFACE_API_HISTORY_S increment by -7 nocache;
select ITF_INTERFACE_API_HISTORY_S.nextval from dual;
alter sequence ITF_INTERFACE_API_HISTORY_S increment by 1 cache 20;
