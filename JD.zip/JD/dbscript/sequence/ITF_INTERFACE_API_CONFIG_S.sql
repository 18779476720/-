-- Create sequence 
create sequence ITF_INTERFACE_API_CONFIG_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 14260
increment by 1
cache 20
cycle;
