-- Create sequence 
create sequence ITF_INTERFACE_API_TEMPLATE_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 21
increment by 1
cache 20;
