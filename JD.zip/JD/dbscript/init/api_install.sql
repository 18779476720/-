﻿WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR  EXIT FAILURE ROLLBACK;

spool INSTALL_ACP4010.log

set feedback off
set define off
begin

--页面注册
---接口
  sys_data_load_pkg.load_sys_service('modules/api/API1020/itf_interface_api.screen','接口定义',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1020/itf_interface_api_structure.screen','接口结构定义',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1010/itf_interface_api_config_query.screen','接口配置',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1010/itf_interface_api_parameter.screen','接口配置参数',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1060/api1060_itf_interface_history.screen','接口历史',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1030/jd_catgorylist_defined.screen','分类配置',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_orderTrack.svc','电商物流',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_on_self.svc','上架',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_product_categorys.svc','京东类目',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1020/jd_api_single_public.svc','京东独立运行接口SVC',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1020/sn_api_single_public.svc','苏宁独立运行接口SVC',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/PUBLIC/itf_interface_api2.svc','晨光通用svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/api/API1060/itf_interface_api_test.svc','接口测试svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_access_token.svc','vop获取tokensvc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_refresh_token.svc','vop刷新tokensvc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_product_page.svc','vop获取商品池svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_page_product.svc','vop获取池内商品svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_product_detail.svc','vop获取商品详情svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_product_image.svc','vop获取商品详情svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_product_category.svc','vop获取分类列表svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_region_provinces.svc','vop获取一级地址',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_region_city.svc','vop获取其他地址',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_sell_price.svc','vop批量获取价格',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/public/jd_api_refresh_token.svc','刷新tokensvc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/kpl/jd_kpl_api_product_page.svc','kpl商品池',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/kpl/jd_kpl_api_page_product.svc','kpl池内商品',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/kpl/jd_kpl_api_product_detail.svc','kpl商品详情',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/kpl/jd_kpl_api_product_image.svc','kpl商品图片',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/kpl/jd_kpl_api_product_sell_price.svc','kpl商品价格',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_detail_load.svc','vop价格和库存',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_submitOrder.svc','订单提交',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_orderInf_query.svc','订单信息查询',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_shopping_cart_validate.svc','购物车校验调用svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_message_get.svc','消息获取svc',0,1,0);  
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_message_handle.svc','消息处理svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_order_track.svc','订单配送信息svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_Jincai_balance.svc','金采余额查询svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_confirm_received.svc','确认收货svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_cancelOrder.svc','取消订单svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_confirmOrder.svc','确认预占svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_confirmOrder_job.svc','JOB确认预占svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_invoice_submit.svc','开票申请svc',0,1,0);
  sys_data_load_pkg.load_sys_service('modules/jd/vop/jd_vop_api_message_handle5.svc','开票申请svc',0,1,0);
  
   /* sys_data_load_pkg.load_sys_service('modules/XY/xy_api_access_token.svc','西域token获取',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_refresh_token.svc','西域token获取',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_product_page.svc','西域获取商品池编号',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_page_product.svc','西域获取池内商品',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_product_detail.svc','西域获取商品详情',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_product_image.svc','西域获取商品图片',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_sell_price.svc','西域获取商品价格',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_sku_info_validate.svc','西域校验svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_submitOrder.svc','西域下单svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_confirmOrder.svc','西域确认下单svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_message_get.svc','西域消息获取svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_message_handle.svc','西域消息处理svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_orderInf_query.svc','西域消息处理svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_invoice_submit.svc','西域消息处理svc',0,1,0);
   sys_data_load_pkg.load_sys_service('modules/XY/api_order_package_query.svc','西域包裹svc',0,1,0); */
  
  
  


end;
/

commit;
set feedback on
set define on

spool off

exit
