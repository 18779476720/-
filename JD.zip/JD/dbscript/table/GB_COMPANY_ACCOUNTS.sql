-- Create table
create table GB_COMPANY_ACCOUNTS
(
  account_id            NUMBER not null,
  coop_business_group   VARCHAR2(30),
  coop_company_id       NUMBER,
  owner_business_group  VARCHAR2(30),
  owner_company_id      NUMBER,
  account_source        VARCHAR2(30) not null,
  user_name             VARCHAR2(200),
  password              VARCHAR2(200),
  app_key               VARCHAR2(200),
  app_secret            VARCHAR2(200),
  client_id             VARCHAR2(200),
  client_secret         VARCHAR2(200),
  grant_type            VARCHAR2(200),
  state                 VARCHAR2(200),
  scope                 VARCHAR2(200),
  access_token          VARCHAR2(200),
  refresh_token         VARCHAR2(200),
  token_expires_in      NUMBER,
  refresh_token_expires DATE,
  enable_flag           VARCHAR2(10),
  comments              VARCHAR2(4000),
  sync_date             DATE,
  account_uid           NUMBER,
  creation_date         DATE,
  created_by            NUMBER,
  last_updated_by       NUMBER,
  last_update_date      DATE
);
-- Add comments to the table 
comment on table GB_COMPANY_ACCOUNTS
  is 'GB�˻�������';
-- Add comments to the columns 
comment on column GB_COMPANY_ACCOUNTS.coop_business_group
  is '������BG';
comment on column GB_COMPANY_ACCOUNTS.coop_company_id
  is '��������˾';
comment on column GB_COMPANY_ACCOUNTS.owner_business_group
  is '���ŷ�BG';
comment on column GB_COMPANY_ACCOUNTS.owner_company_id
  is '���ŷ���˾';
comment on column GB_COMPANY_ACCOUNTS.account_source
  is '�˻�������Դ';
comment on column GB_COMPANY_ACCOUNTS.user_name
  is '�˻���';
comment on column GB_COMPANY_ACCOUNTS.password
  is '�˻�����';
comment on column GB_COMPANY_ACCOUNTS.app_key
  is 'app_key';
comment on column GB_COMPANY_ACCOUNTS.app_secret
  is 'app_secret';
comment on column GB_COMPANY_ACCOUNTS.client_id
  is 'client_id';
comment on column GB_COMPANY_ACCOUNTS.client_secret
  is 'client_secret';
comment on column GB_COMPANY_ACCOUNTS.grant_type
  is '��֤����';
comment on column GB_COMPANY_ACCOUNTS.state
  is 'state';
comment on column GB_COMPANY_ACCOUNTS.scope
  is 'scope';
comment on column GB_COMPANY_ACCOUNTS.access_token
  is 'access_token';
comment on column GB_COMPANY_ACCOUNTS.refresh_token
  is '�ӿ�refresh_token';
comment on column GB_COMPANY_ACCOUNTS.token_expires_in
  is 'access_token����ʱ��';
comment on column GB_COMPANY_ACCOUNTS.refresh_token_expires
  is 'refresh_token����ʱ��';
comment on column GB_COMPANY_ACCOUNTS.enable_flag
  is '�Ƿ�����';
comment on column GB_COMPANY_ACCOUNTS.comments
  is '��ע';
comment on column GB_COMPANY_ACCOUNTS.sync_date
  is '����ͬ��ʱ��';
-- Create/Recreate indexes 
create index IDX_OWNER_BG on GB_COMPANY_ACCOUNTS (OWNER_BUSINESS_GROUP, OWNER_COMPANY_ID));
create index IDX_USER_NAME on GB_COMPANY_ACCOUNTS (COOP_BUSINESS_GROUP, COOP_COMPANY_ID);
-- Create/Recreate primary, unique and foreign key constraints 
alter table GB_COMPANY_ACCOUNTS
  add constraint GB_COMPANY_ACCOUNTS_PK primary key (ACCOUNT_ID);
