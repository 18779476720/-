-- Create table
create table JD_PRODUCT_GETCATEGORYS
(
  catid            INTEGER not null,
  parentid         INTEGER,
  name             VARCHAR2(2000),
  catclass         INTEGER,
  state            INTEGER,
  created_by       NUMBER,
  creation_date    DATE,
  last_updated_by  NUMBER,
  last_update_date DATE not null,
  show_flag        VARCHAR2(100),
  show_order       NUMBER,
  show_name        VARCHAR2(200),
  page_no          NUMBER
);
-- Add comments to the columns 
comment on column JD_PRODUCT_GETCATEGORYS.catid
  is '����ID';
comment on column JD_PRODUCT_GETCATEGORYS.parentid
  is '�ϼ�����ID';
comment on column JD_PRODUCT_GETCATEGORYS.name
  is '������';
comment on column JD_PRODUCT_GETCATEGORYS.catclass
  is '����ȼ�';
comment on column JD_PRODUCT_GETCATEGORYS.state
  is '״̬';
comment on column JD_PRODUCT_GETCATEGORYS.show_flag
  is '��ʾ��־';
comment on column JD_PRODUCT_GETCATEGORYS.show_order
  is 'չʾ˳��';
comment on column JD_PRODUCT_GETCATEGORYS.show_name
  is 'չʾ��';
comment on column JD_PRODUCT_GETCATEGORYS.page_no
  is 'ҳ��';
-- Create/Recreate indexes 
create index JD_PRODUCT_GETCATEGORYS_N1 on JD_PRODUCT_GETCATEGORYS (CATID);
create index JD_PRODUCT_GETCATEGORYS_N2 on JD_PRODUCT_GETCATEGORYS (PARENTID);
create index JD_PRODUCT_GETCATEGORYS_N3 on JD_PRODUCT_GETCATEGORYS (NAME);
create index JD_PRODUCT_GETCATEGORYS_N4 on JD_PRODUCT_GETCATEGORYS (CATCLASS);
