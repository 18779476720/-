-- Create table
create table ITF_INTERFACE_API
(
  api_id           NUMBER not null,
  config_id        NUMBER,
  api_code         VARCHAR2(30),
  api_desc         VARCHAR2(200),
  enabled_flag     VARCHAR2(1),
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  procedure        VARCHAR2(200),
  pre_procedure    VARCHAR2(200)
);
-- Add comments to the table 
comment on table ITF_INTERFACE_API
  is '�ӿڶ����';
-- Add comments to the columns 
comment on column ITF_INTERFACE_API.api_id
  is 'PK';
comment on column ITF_INTERFACE_API.config_id
  is '����ID';
comment on column ITF_INTERFACE_API.api_code
  is '�ӿڱ���';
comment on column ITF_INTERFACE_API.api_desc
  is '�ӿ�˵��';
comment on column ITF_INTERFACE_API.enabled_flag
  is '����';
comment on column ITF_INTERFACE_API.procedure
  is '��������';
comment on column ITF_INTERFACE_API.pre_procedure
  is 'Ԥ��������';
-- Create/Recreate primary, unique and foreign key constraints 
alter table ITF_INTERFACE_API
  add constraint ITF_INTERFACE_API_PK primary key (API_ID);
alter table ITF_INTERFACE_API
  add constraint ITF_INTERFACE_API_U1 unique (CONFIG_ID, API_CODE);
