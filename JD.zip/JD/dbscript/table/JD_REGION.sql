-- Create table
create table JD_REGION
(
  region_id          NUMBER not null,
  region_code        NUMBER not null,
  region_name        VARCHAR2(200) not null,
  parent_region_code NUMBER,
  level_num          NUMBER,
  enable_flag        VARCHAR2(2),
  created_by         NUMBER not null,
  creation_date      DATE not null,
  last_updated_by    NUMBER not null,
  last_update_date   DATE not null
);
-- Add comments to the columns 
comment on column JD_REGION.region_id
  is '����';
comment on column JD_REGION.region_code
  is '��ַ���';
comment on column JD_REGION.region_name
  is '��ַ��';
comment on column JD_REGION.parent_region_code
  is '�ϼ���ַ���';
comment on column JD_REGION.level_num
  is '��ַ�ȼ�';
comment on column JD_REGION.enable_flag
  is '���ñ�־';
-- Create/Recreate indexes 
create index IDX_NAME_PARENT_CODE on JD_REGION (REGION_NAME, PARENT_REGION_CODE);
create index IDX_REGION_CODE on JD_REGION (REGION_CODE);
create index IDX_REGION_NAME on JD_REGION (REGION_NAME);
-- Create/Recreate primary, unique and foreign key constraints 
alter table JD_REGION
  add constraint REGION_ID_PK primary key (REGION_ID);
