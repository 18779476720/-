-- Create table
create table ITF_INTERFACE_API_CONFIG
(
  config_id        NUMBER not null,
  config_code      VARCHAR2(30) not null,
  config_desc      VARCHAR2(400),
  url              VARCHAR2(2000),
  comments         VARCHAR2(4000),
  enabled_flag     VARCHAR2(1),
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER
);
-- Add comments to the table 
comment on table ITF_INTERFACE_API_CONFIG
  is '�ӿ����ñ�';
-- Add comments to the columns 
comment on column ITF_INTERFACE_API_CONFIG.config_id
  is 'PK';
comment on column ITF_INTERFACE_API_CONFIG.config_code
  is '���ñ���';
comment on column ITF_INTERFACE_API_CONFIG.config_desc
  is '��������';
comment on column ITF_INTERFACE_API_CONFIG.url
  is '��������';
comment on column ITF_INTERFACE_API_CONFIG.comments
  is '��ע';
comment on column ITF_INTERFACE_API_CONFIG.enabled_flag
  is '����';
-- Create/Recreate primary, unique and foreign key constraints 
alter table ITF_INTERFACE_API_CONFIG
  add constraint ITF_INTERFACE_API_CONFIG_PK primary key (CONFIG_ID);
alter table ITF_INTERFACE_API_CONFIG
  add constraint ITF_INTERFACE_API_CONFIG_U1 unique (CONFIG_CODE);
