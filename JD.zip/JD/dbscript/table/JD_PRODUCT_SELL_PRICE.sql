-- Create table
create table JD_PRODUCT_SELL_PRICE
(
  sku              NUMBER,
  jd_price         NUMBER,
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  price            NUMBER,
  tax_price        NUMBER,
  naked_price      NUMBER,
  tax              NUMBER
);
-- Add comments to the columns 
comment on column JD_PRODUCT_SELL_PRICE.jd_price
  is '��Ʒ�����۸� ';
comment on column JD_PRODUCT_SELL_PRICE.price
  is '�ͻ�����۸�';
comment on column JD_PRODUCT_SELL_PRICE.tax_price
  is '˰��';
comment on column JD_PRODUCT_SELL_PRICE.naked_price
  is '���';
comment on column JD_PRODUCT_SELL_PRICE.tax
  is '˰��';
