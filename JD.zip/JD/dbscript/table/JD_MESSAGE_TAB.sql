-- Create table
create table JD_MESSAGE_TAB
(
  message_id       NUMBER not null,
  business_group   VARCHAR2(200),
  id               NUMBER,
  result           CLOB,
  time             DATE,
  type             NUMBER,
  handle_status    VARCHAR2(30),
  creation_date    DATE default sysdate not null,
  created_by       NUMBER default -1 not null,
  last_updated_by  NUMBER default -1 not null,
  last_update_date DATE default sysdate not null,
  error_message    VARCHAR2(2000)
);
-- Add comments to the table 
comment on table JD_MESSAGE_TAB
  is '������Ϣ��';
-- Add comments to the columns 
comment on column JD_MESSAGE_TAB.message_id
  is '����';
comment on column JD_MESSAGE_TAB.business_group
  is '��Ϣ����BG';
comment on column JD_MESSAGE_TAB.id
  is '����ID';
comment on column JD_MESSAGE_TAB.result
  is '��������';
comment on column JD_MESSAGE_TAB.time
  is '����ʱ��';
comment on column JD_MESSAGE_TAB.type
  is '��������';
comment on column JD_MESSAGE_TAB.handle_status
  is '����״̬';
comment on column JD_MESSAGE_TAB.error_message
  is '������Ϣ';
-- Create/Recreate indexes 
create index JD_MESSAGE_TAB_N1 on JD_MESSAGE_TAB (ID);
create index JD_MESSAGE_TAB_N2 on JD_MESSAGE_TAB (TIME);
