-- Create table
create table ITF_INTERFACE_API_HISTORY
(
  history_id       NUMBER not null,
  config_id        NUMBER,
  url              VARCHAR2(4000),
  request_data     CLOB,
  response_data    CLOB,
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  api_id           NUMBER,
  status           VARCHAR2(30),
  error_message    VARCHAR2(4000)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table ITF_INTERFACE_API_HISTORY
  add constraint ITF_INTERFACE_API_HISTORY_PK primary key (HISTORY_ID);
-- Create/Recreate check constraints 
alter table ITF_INTERFACE_API_HISTORY
  add constraint ITF_API_REQ_JSON_CK
  check (request_data is json);
alter table ITF_INTERFACE_API_HISTORY
  add constraint ITF_API_RES_JSON_CK
  check (response_data is json);
