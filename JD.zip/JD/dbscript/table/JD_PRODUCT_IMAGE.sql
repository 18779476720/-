-- Create table
create table JD_PRODUCT_IMAGE
(
  id               NUMBER,
  skuid            NUMBER,
  path             VARCHAR2(500),
  created          DATE,
  modified         DATE,
  yn               NUMBER,
  isprimary        NUMBER,
  ordersort        NUMBER,
  position         NUMBER,
  type             NUMBER,
  features         VARCHAR2(100),
  sync_date        DATE default sysdate,
  creation_date    DATE default sysdate,
  created_by       NUMBER default 1,
  last_update_date DATE default sysdate,
  last_updated_by  NUMBER default 1
));
-- Add comments to the table 
comment on table JD_PRODUCT_IMAGE
  is '��ƷͼƬ��Ϣ';
