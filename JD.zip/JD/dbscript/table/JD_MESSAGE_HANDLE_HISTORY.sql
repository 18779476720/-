-- Create table
create table JD_MESSAGE_HANDLE_HISTORY
(
  history_id           NUMBER,
  message_id           NUMBER not null,
  business_group       VARCHAR2(200),
  id                   NUMBER,
  result               CLOB,
  time                 DATE,
  type                 NUMBER,
  handle_status        VARCHAR2(30),
  msg_creation_date    DATE default sysdate not null,
  msg_created_by       NUMBER default -1 not null,
  msg_last_updated_by  NUMBER default -1 not null,
  msg_last_update_date DATE default sysdate not null,
  creation_date        DATE default sysdate not null,
  created_by           NUMBER default -1 not null,
  last_updated_by      NUMBER default -1 not null,
  last_update_date     DATE default sysdate not null
);
-- Add comments to the table 
comment on table JD_MESSAGE_HANDLE_HISTORY
  is '������Ϣ��ʷ��';
-- Add comments to the columns 
comment on column JD_MESSAGE_HANDLE_HISTORY.message_id
  is '����';
comment on column JD_MESSAGE_HANDLE_HISTORY.business_group
  is '��Ϣ����BG';
comment on column JD_MESSAGE_HANDLE_HISTORY.id
  is '����ID';
comment on column JD_MESSAGE_HANDLE_HISTORY.result
  is '��������';
comment on column JD_MESSAGE_HANDLE_HISTORY.time
  is '����ʱ��';
comment on column JD_MESSAGE_HANDLE_HISTORY.type
  is '��������';
comment on column JD_MESSAGE_HANDLE_HISTORY.handle_status
  is '����״̬';
