-- Create table
create table JD_PRODUCT_DETAIL
(
  sku              NUMBER not null,
  name             VARCHAR2(2000),
  category         VARCHAR2(200),
  sale_unit        VARCHAR2(200),
  weight           NUMBER,
  product_area     VARCHAR2(200),
  ware_qd          VARCHAR2(4000),
  image_path       VARCHAR2(4000),
  param            CLOB,
  state            NUMBER,
  barnd_name       VARCHAR2(2000),
  upc              VARCHAR2(2000),
  introduction     CLOB,
  sync_date        DATE,
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  enable_flag      VARCHAR2(20),
  category_id      NUMBER
);
-- Add comments to the columns 
comment on column JD_PRODUCT_DETAIL.sku
  is 'sku';
comment on column JD_PRODUCT_DETAIL.name
  is '��Ʒ��';
comment on column JD_PRODUCT_DETAIL.category
  is '����';
comment on column JD_PRODUCT_DETAIL.sale_unit
  is '���۵�λ';
comment on column JD_PRODUCT_DETAIL.weight
  is '����';
comment on column JD_PRODUCT_DETAIL.product_area
  is '����';
comment on column JD_PRODUCT_DETAIL.ware_qd
  is '�嵥';
comment on column JD_PRODUCT_DETAIL.image_path
  is '��ͼƬ��ַ';
comment on column JD_PRODUCT_DETAIL.param
  is '������';
comment on column JD_PRODUCT_DETAIL.state
  is '���¼�״̬';
comment on column JD_PRODUCT_DETAIL.barnd_name
  is 'Ʒ��';
comment on column JD_PRODUCT_DETAIL.upc
  is '������';
comment on column JD_PRODUCT_DETAIL.introduction
  is '��ϸ����';
comment on column JD_PRODUCT_DETAIL.enable_flag
  is '���ñ�־';
comment on column JD_PRODUCT_DETAIL.category_id
  is '3�������ַ';
-- Create/Recreate indexes 
create index JD_PRODUCT_DETAIL_N1 on JD_PRODUCT_DETAIL (SKU);
create index JD_PRODUCT_DETAIL_N2 on JD_PRODUCT_DETAIL (NAME);
create index JD_PRODUCT_DETAIL_N3 on JD_PRODUCT_DETAIL (BARND_NAME);
