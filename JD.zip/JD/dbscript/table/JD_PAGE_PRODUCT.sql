-- Create table
create table JD_PAGE_PRODUCT
(
  page_num         VARCHAR2(200),
  skuid            NUMBER,
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  sync_date        DATE,
  page_count       NUMBER,
  page_no          NUMBER
);
