-- Create table
create table ITF_INTERFACE_API_TEMPLATE
(
  template_id      NUMBER not null,
  api_id           NUMBER,
  api_code         VARCHAR2(200),
  request_para     VARCHAR2(1000),
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  config_id        NUMBER,
  config_code      VARCHAR2(50),
  config_desc      VARCHAR2(50),
  api_result       CLOB,
  request_url      VARCHAR2(1000)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table ITF_INTERFACE_API_TEMPLATE
  add constraint ITF_INTERFACE_API_TEMPLATE_PK primary key (TEMPLATE_ID);
alter table ITF_INTERFACE_API_TEMPLATE
  add constraint ITF_INTERFACE_API_TEMPLATE_U1 unique (API_CODE);
