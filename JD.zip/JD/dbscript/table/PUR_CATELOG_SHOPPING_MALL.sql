-- Create table
create table PUR_CATELOG_SHOPPING_MALL
(
  mall_id            NUMBER not null,
  item_id            NUMBER not null,
  display_item_code  VARCHAR2(200) not null,
  data_source        VARCHAR2(30) not null,
  item_name          VARCHAR2(2000) not null,
  brand              VARCHAR2(1000),
  item_model         VARCHAR2(1000),
  image_url          VARCHAR2(1000),
  item_category_id   NUMBER not null,
  price              NUMBER not null,
  vendor_name        VARCHAR2(2000) not null,
  creation_date      DATE not null,
  created_by         NUMBER not null,
  last_update_date   DATE not null,
  last_updated_by    NUMBER not null,
  stage              NUMBER,
  third_category_id  NUMBER,
  second_category_id NUMBER
);
-- Add comments to the table 
comment on table PUR_CATELOG_SHOPPING_MALL
  is 'Ŀ¼���̳���Ʒ';
-- Add comments to the columns 
comment on column PUR_CATELOG_SHOPPING_MALL.mall_id
  is 'PK';
comment on column PUR_CATELOG_SHOPPING_MALL.item_id
  is '����ID/SKU';
comment on column PUR_CATELOG_SHOPPING_MALL.display_item_code
  is '���ϱ���/SKU';
comment on column PUR_CATELOG_SHOPPING_MALL.data_source
  is '������Դ';
comment on column PUR_CATELOG_SHOPPING_MALL.item_name
  is '����/��Ʒ����';
comment on column PUR_CATELOG_SHOPPING_MALL.brand
  is 'Ʒ��';
comment on column PUR_CATELOG_SHOPPING_MALL.item_model
  is '���';
comment on column PUR_CATELOG_SHOPPING_MALL.image_url
  is '��ͼ��ַ';
comment on column PUR_CATELOG_SHOPPING_MALL.item_category_id
  is '����id';
comment on column PUR_CATELOG_SHOPPING_MALL.price
  is '�۸�';
comment on column PUR_CATELOG_SHOPPING_MALL.vendor_name
  is '��Ӧ������';
comment on column PUR_CATELOG_SHOPPING_MALL.stage
  is '���¼�״̬';
comment on column PUR_CATELOG_SHOPPING_MALL.third_category_id
  is '������ĩ��ƽ̨���ࣩ';
comment on column PUR_CATELOG_SHOPPING_MALL.second_category_id
  is '�������μ�ƽ̨���ࣩ';
-- Create/Recreate indexes 
create index PUR_CATELOG_SHOPPING_MALL_N1 on PUR_CATELOG_SHOPPING_MALL (ITEM_NAME);
create index PUR_CATELOG_SHOPPING_MALL_N2 on PUR_CATELOG_SHOPPING_MALL (BRAND);
create index PUR_CATELOG_SHOPPING_MALL_N3 on PUR_CATELOG_SHOPPING_MALL (ITEM_MODEL);
create index PUR_CATELOG_SHOPPING_MALL_N4 on PUR_CATELOG_SHOPPING_MALL (ITEM_CATEGORY_ID);
create index PUR_CATELOG_SHOPPING_MALL_N5 on PUR_CATELOG_SHOPPING_MALL (PRICE);
create index PUR_CATELOG_SHOPPING_MALL_N6 on PUR_CATELOG_SHOPPING_MALL (PRICE DESC);
create index PUR_CATELOG_SHOPPING_MALL_N7 on PUR_CATELOG_SHOPPING_MALL (VENDOR_NAME);
create index PUR_CATELOG_SHOPPING_MALL_N8 on PUR_CATELOG_SHOPPING_MALL (THIRD_CATEGORY_ID);
create index PUR_CATELOG_SHOPPING_MALL_N9 on PUR_CATELOG_SHOPPING_MALL (SECOND_CATEGORY_ID);
create unique index PUR_CATELOG_SHOPPING_MALL_U1 on PUR_CATELOG_SHOPPING_MALL (ITEM_ID, DATA_SOURCE));
create unique index PUR_CATELOG_SHOPPING_MALL_U2 on PUR_CATELOG_SHOPPING_MALL (DISPLAY_ITEM_CODE);
-- Create/Recreate primary, unique and foreign key constraints 
alter table PUR_CATELOG_SHOPPING_MALL
  add constraint PUR_CATELOG_SHOPPING_MALL_PK primary key (MALL_ID)
  using index;
