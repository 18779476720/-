-- Create table
create table JD_PRODUCT_PAGE
(
  name             VARCHAR2(200),
  page_num         VARCHAR2(200),
  creation_date    DATE,
  created_by       NUMBER,
  last_update_date DATE,
  last_updated_by  NUMBER,
  sync_date        DATE,
  sync_status      VARCHAR2(200),
  page_count       NUMBER
);
-- Add comments to the columns 
comment on column JD_PRODUCT_PAGE.page_count
  is '��Ʒҳ��';
