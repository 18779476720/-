/*     */ package aurora.presentation.component.std;
/*     */ 
/*     */ import aurora.application.ApplicationConfig;
/*     */ import aurora.application.ApplicationViewConfig;
/*     */ import aurora.application.IApplicationConfig;
/*     */ import aurora.application.config.ScreenConfig;
/*     */ import aurora.presentation.BuildSession;
/*     */ import aurora.presentation.ViewContext;
/*     */ import aurora.presentation.component.std.config.ComponentConfig;
/*     */ import aurora.presentation.component.std.config.EventConfig;
/*     */ import aurora.presentation.markup.HtmlPageContext;
/*     */ import aurora.service.IService;
/*     */ import aurora.service.ServiceInstance;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ import uncertain.composite.CompositeMap;
/*     */ import uncertain.composite.TextParser;
/*     */ import uncertain.ocm.IObjectRegistry;
/*     */ 
/*     */ public class Component
/*     */ {
/*     */   public static final String VERSION = "$Revision: 8441 $";
/*     */   protected static final String CONFIG = "config";
/*     */   protected static final String WRAP_CSS = "wrapClass";
/*     */   protected static final String BINDING = "binding";
/*     */   public static final String THEME_DEFAULT = "default";
/*     */   public static final String THEME_MAC = "mac";
/*     */   protected String id;
/*  49 */   private JSONObject listeners = new JSONObject();
/*  50 */   private StringBuilder bsb = new StringBuilder();
/*  51 */   private JSONObject config = new JSONObject();
/*     */   protected ApplicationConfig mApplicationConfig;
/*     */ 
/*     */   public Component(IObjectRegistry registry)
/*     */   {
/*  55 */     this.mApplicationConfig = ((ApplicationConfig)registry.getInstanceOfType(IApplicationConfig.class));
/*     */   }
/*     */ 
/*     */   public void onPreparePageContent(BuildSession session, ViewContext context) throws IOException
/*     */   {
/*  60 */     addStyleSheet(session, context, "base/Aurora-all-min.css");
/*  61 */     addJavaScript(session, context, "base/ext-core-min.js");
			  addJavaScript(session, context, "base/crypto-js.js");
/*  62 */     addJavaScript(session, context, "base/Aurora-all-min.js");
			  addJavaScript(session, context, "base/crypto-js-aurora.js");
/*  63 */     addJavaScript(session, context, "locale/aurora-lang-" + session.getLanguage() + ".js");
/*     */   }
/*     */ 
/*     */   protected String getDefaultClass(BuildSession session, ViewContext context)
/*     */   {
/*  68 */     return "";
/*     */   }
/*     */ 
/*     */   protected int getDefaultWidth() {
/*  72 */     return 150;
/*     */   }
/*     */ 
/*     */   protected int getDefaultHeight() {
/*  76 */     return 20;
/*     */   }
/*     */ 
/*     */   protected Integer getComponentWidth(CompositeMap model, CompositeMap view, Map map) {
/*  80 */     CompositeMap root = model.getRoot();
/*  81 */     CompositeMap vwc = null;
/*  82 */     ComponentConfig cc = new ComponentConfig();
/*  83 */     cc.initialize(view);
/*     */ 
/*  85 */     String vws = null;
/*  86 */     Integer vw = null;
/*  87 */     if (root != null) {
/*  88 */       vws = (String)root.getObject("/parameter/@_vw");
/*  89 */       if (vws == null) {
/*  90 */         vwc = (CompositeMap)root.getObject("/cookie/@vw");
/*  91 */         if ((vwc != null) && (!vwc.get("value").equals("NaN")))
/*  92 */           vw = vwc.getInt("value");
/*     */       }
/*     */       else {
/*  95 */         vw = Integer.valueOf(vws);
/*     */       }
/*     */     }
/*  98 */     String widthStr = view.getString(ComponentConfig.PROPERTITY_WIDTH, ""+ getDefaultWidth());
/*  99 */     String wstr = TextParser.parse(widthStr, model);
/* 100 */     Integer width = "".equals(wstr) ? new Integer(getDefaultWidth()) : Integer.valueOf(wstr);
/* 101 */     map.put("oldwidth", width);
/* 102 */     Integer marginWidth = cc.getMarginWidth(model);
/* 103 */     if ((marginWidth != null) && (vw != null)) {
/* 104 */       width = new Integer(vw.intValue() - marginWidth.intValue() > 0 ? vw.intValue() - marginWidth.intValue() : width.intValue());
/*     */ 
/* 107 */       addConfig("marginwidth", marginWidth);
/*     */     }
/* 109 */     return width;
/*     */   }
/*     */ 
/*     */   protected Integer getComponentHeight(CompositeMap model, CompositeMap view, Map map) {
/* 113 */     CompositeMap root = model.getRoot();
/* 114 */     CompositeMap vhc = null;
/* 115 */     ComponentConfig cc = new ComponentConfig();
/* 116 */     cc.initialize(view);
/*     */ 
/* 118 */     String vhs = null;
/* 119 */     Integer vh = null;
/* 120 */     if (root != null) {
/* 121 */       vhs = (String)root.getObject("/parameter/@_vh");
/* 122 */       if (vhs == null) {
/* 123 */         vhc = (CompositeMap)root.getObject("/cookie/@vh");
/* 124 */         if ((vhc != null) && (!vhc.get("value").equals("NaN")))
/*     */         {
/* 126 */           vh = vhc.getInt("value");
/*     */         }
/*     */       } else {
/* 129 */         vh = Integer.valueOf(vhs);
/*     */       }
/*     */     }
/* 132 */     String heightStr = view.getString(ComponentConfig.PROPERTITY_HEIGHT, "" + getDefaultHeight());
/* 133 */     String hstr = TextParser.parse(heightStr, model);
/* 134 */     Integer height = "".equals(hstr) ? new Integer(getDefaultHeight()) : Integer.valueOf(hstr);
/* 135 */     Integer marginHeight = cc.getMarginHeight(model);
/* 136 */     if ((marginHeight != null) && (vh != null))
/*     */     {
/* 138 */       height = new Integer(vh.intValue() - marginHeight.intValue() > 0 ? vh.intValue() - marginHeight.intValue() : height.intValue());
/* 139 */       addConfig("marginheight", marginHeight);
/*     */     }
/* 141 */     return height;
/*     */   }
/*     */ 
/*     */   public void onCreateViewContent(BuildSession session, ViewContext context) throws IOException {
/* 145 */     CompositeMap view = context.getView();
/* 146 */     CompositeMap model = context.getModel();
/* 147 */     CompositeMap root = model.getRoot();
/* 148 */     Map map = context.getMap();
/* 149 */     ComponentConfig cc = new ComponentConfig();
/* 150 */     cc.initialize(view);
/* 151 */     ApplicationViewConfig view_config = this.mApplicationConfig.getApplicationViewConfig();
/*     */ 
/* 153 */     Boolean isCust = cc.isCust();
/*     */ 
/* 155 */     this.id = cc.getId();
/* 156 */     this.id = TextParser.parse(this.id, model);
/* 157 */     if ((this.id == null) || ("".equals(this.id)))
/* 158 */       this.id = IDGenerator.getInstance().generate();
/* 159 */     else if (isCust == null) {
/* 160 */       isCust = new Boolean(true);
/*     */     }
/* 162 */     addConfig("iscust", isCust);
/* 163 */     map.put("id", this.id);
/* 164 */     addConfig("id", this.id);
/*     */ 
/* 166 */     String hostId = cc.getHostId();
/* 167 */     if (hostId != null) {
/* 168 */       addConfig("hostid", hostId);
/*     */     } else {
/* 170 */       String rootHostId = (String)root.getObject("/parameter/@_hostid");
/* 171 */       if (rootHostId != null) {
/* 172 */         addConfig("hostid", rootHostId);
/*     */       }
/*     */     }
/* 175 */     String clazz = getDefaultClass(session, context);
/* 176 */     String className = cc.getClassName();
/* 177 */     if (className != null) {
/* 178 */       clazz = clazz + " " + className;
/*     */     }
/* 180 */     map.put("wrapClass", clazz);
/*     */ 
/* 182 */     map.put("tabindex", Integer.valueOf(cc.getTabIndex()));
/*     */ 
/* 185 */     Integer width = getComponentWidth(model, view, map);
/* 186 */     map.put("width", width);
/* 187 */     addConfig("width", width);
/*     */ 
/* 190 */     Integer height = getComponentHeight(model, view, map);
/* 191 */     if (height.intValue() != 0) {
/* 192 */       map.put("height", height);
/* 193 */       addConfig("height", height);
/*     */     }
/*     */ 
/* 197 */     String name = cc.getName();
/* 198 */     if (name == null) {
/* 199 */       name = IDGenerator.getInstance().generate();
/*     */     }
/* 201 */     map.put("name", name);
/*     */ 
/* 203 */     String style = cc.getStyle(model);
/* 204 */     map.put("style", style == null ? "" : style);
/*     */ 
/* 207 */     String value = cc.getValue();
/* 208 */     map.put("value", value == null ? "" : value);
/*     */ 
/* 210 */     addConfig("clientresize", Boolean.valueOf(cc.isClientResize() == null ? view_config.getDefaultClientResize() : cc.isClientResize().booleanValue()));
/*     */ 
/* 213 */     boolean hidden = cc.getHidden(false).booleanValue();
/* 214 */     if (hidden) {
/* 215 */       addConfig("hidden", Boolean.valueOf(hidden));
/*     */     }
/*     */ 
/* 218 */     CompositeMap events = view.getChild("events");
/* 219 */     if (events != null) {
/* 220 */       List list = events.getChilds();
/* 221 */       if (list != null) {
/* 222 */         Iterator it = list.iterator();
/* 223 */         while (it.hasNext()) {
/* 224 */           CompositeMap event = (CompositeMap)it.next();
/* 225 */           EventConfig eventConfig = EventConfig.getInstance(event);
/* 226 */           String eventName = eventConfig.getEventName();
/* 227 */           String handler = eventConfig.getHandler();
/* 228 */           if ((!"".equals(eventName)) && (!"".equals(handler)))
/* 229 */             handler = TextParser.parse(handler, model);
/* 230 */           addEvent(this.id, eventName, handler);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 236 */     addConfig("listeners", this.listeners);
/*     */ 
/* 239 */     String bindTarget = cc.getBindTarget();
/* 240 */     if (!bindTarget.equals("")) {
/* 241 */       bindTarget = TextParser.parse(bindTarget, model);
/* 242 */       map.put("bindtarget", bindTarget);
/* 243 */       this.bsb.append("$('" + this.id + "').bind('" + bindTarget + "','" + name + "');\n");
/* 244 */       map.put("binding", this.bsb.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addJavaScript(BuildSession session, ViewContext context, String javascript)
/*     */   {
/* 257 */     if (!session.includeResource(javascript)) {
/* 258 */       HtmlPageContext page = HtmlPageContext.getInstance(context);
/* 259 */       String js = session.getResourceUrl(javascript);
/* 260 */       page.addScript(js);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addStyleSheet(BuildSession session, ViewContext context, String style)
/*     */   {
/* 273 */     if (!session.includeResource(style)) {
/* 274 */       HtmlPageContext page = HtmlPageContext.getInstance(context);
/* 275 */       String styleSheet = session.getResourceUrl(style);
/* 276 */       page.addStyleSheet(styleSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addEvent(String id, String eventName, String handler)
/*     */   {
/*     */     try
/*     */     {
/* 290 */       this.listeners.put(eventName, new JSONFunction(handler));
/*     */     }
/*     */     catch (JSONException localJSONException)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addConfig(String key, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 303 */       this.config.put(key, value);
/*     */     } catch (JSONException e) {
/* 305 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getConfigString()
/*     */   {
/* 315 */     return this.config.toString();
/*     */   }
/*     */ 
/*     */   protected JSONObject getConfig() {
/* 319 */     return this.config;
/*     */   }
/*     */ 
/*     */   protected String getFieldPrompt(BuildSession session, CompositeMap field, String dataset) {
/* 323 */     String label = field.getString("prompt", "");
/* 324 */     if ("".equals(label)) {
/* 325 */       String name = field.getString("name", "");
/* 326 */       CompositeMap ds = getDataSet(session, dataset);
/* 327 */       if (ds != null) {
/* 328 */         CompositeMap fieldcm = ds.getChild("fields");
/* 329 */         if (fieldcm != null) {
/* 330 */           List fields = fieldcm.getChilds();
/* 331 */           Iterator it = fields.iterator();
/* 332 */           while (it.hasNext()) {
/* 333 */             CompositeMap fieldMap = (CompositeMap)it.next();
/* 334 */             String fn = fieldMap.getString("name", "");
/* 335 */             if (name.equals(fn)) {
/* 336 */               label = fieldMap.getString("prompt", "");
/* 337 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 343 */     return label;
/*     */   }
/*     */ 
/*     */   private CompositeMap getDataSet(BuildSession session, String dataSetName) {
/* 347 */     CompositeMap dataset = null;
/* 348 */     ServiceInstance svc = (ServiceInstance)session.getInstanceOfType(IService.class);
/* 349 */     ScreenConfig screen = ScreenConfig.createScreenConfig(svc.getServiceConfigData());
/* 350 */     CompositeMap datasets = screen.getDataSetsConfig();
/* 351 */     if (datasets != null) {
/* 352 */       List list = datasets.getChilds();
/* 353 */       Iterator it = list.iterator();
/* 354 */       while (it.hasNext()) {
/* 355 */         CompositeMap ds = (CompositeMap)it.next();
/* 356 */         String dsname = ds.getString("id", "");
/* 357 */         if (dataSetName.equals(dsname)) {
/* 358 */           dataset = ds;
/* 359 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 363 */     return dataset;
/*     */   }
/*     */ 
/*     */   public boolean isHidden(CompositeMap view, CompositeMap model) {
/* 367 */     CompositeMap cd = model.getParent().getChild("_customization_data");
/* 368 */     if (cd != null) {
/* 369 */       List list = cd.getChilds();
/* 370 */       Iterator it = list.iterator();
/* 371 */       String fid = view.getString("id", "");
/* 372 */       while (it.hasNext()) {
/* 373 */         CompositeMap record = (CompositeMap)it.next();
/* 374 */         String id = record.getString("id_value");
/* 375 */         String mt = record.getString("mod_type");
/* 376 */         String ak = record.getString("attrib_key");
/* 377 */         String av = record.getString("attrib_value");
/* 378 */         String an = record.getString("array_name");
/* 379 */         String idf = record.getString("index_field");
/* 380 */         String idv = record.getString("index_value");
/* 381 */         if (("set_attrib".equals(mt)) && (id.equals(fid)) && ("hidden".equals(ak)) && ("true".equals(av)) && (an == null) && (idf == null) && (idv == null)) {
/* 382 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 386 */     return false;
/*     */   }
/*     */ 
/*     */   public int getChildLength(CompositeMap view, CompositeMap model) {
/* 390 */     int count = 0;
/* 391 */     Iterator it = view.getChildIterator();
/* 392 */     if (it != null)
/* 393 */       while (it.hasNext()) {
/* 394 */         CompositeMap field = (CompositeMap)it.next();
/* 395 */         if (!isHidden(field, model))
/*     */         {
/* 398 */           count++;
/*     */         }
/*     */       }
/* 401 */     return count;
/*     */   }
/*     */ }

/* Location:           C:\Users\IsaacF\Desktop\aurora.jar
 * Qualified Name:     aurora.presentation.component.std.Component
 * JD-Core Version:    0.6.2
 */