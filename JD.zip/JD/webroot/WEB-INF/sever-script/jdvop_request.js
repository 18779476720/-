importPackage(Packages.aurora.plugin.security);

importPackage(java.io);
importPackage(java.lang);
importPackage(java.util);
importPackage(Packages.aurora.plugin.util);

var logger = $logger('server-script');

function log(msg) {
	logger.info(msg);
}

function request(args) {
	if (!args)
		args = {};
	var url = args.url || '';
	var para = args.para || {};
	var _success = args['success'] || function() {
	};
	var _failure = args['failure'] || function() {
	};

	var data = para;

	/*// 将参数转换为MAP
	var data_map = new HashMap();
	var str = new java.lang.String(para);

	for ( var key in data) {
		var key_value = data[key];
		if (key == 'sku') {
			key_value = JSON.stringify(data[key]);
		}
		data_map.put(key, key_value);
	}
	 //log(data_map);
*/	
	var data = JSON.stringify(para);
	//log('para'+data);京东vop模式接收正确json，正常传到此处的para就是json，
	//开始直接调用请求错误，强加两次格式转换后正确！
	var ret;
	var ret_json;
	var da=JSON.parse(String(data));
	log('request:'+JSON.stringify(da));
	try {
		var is = Packages.aurora.plugin.util.HttpUtils.urlPost(url, da,"UTF-8");
		ret = Packages.aurora.plugin.util.IOUtilsEx.newString(is, "UTF-8");
		var return_data_json = JSON.parse(String(ret));
	} catch (e) {
		_failure({
			"success" : false,
			"error" : {
				"code" : "error",
				"message" : e.message
			}
		})
		return;
	}
	_success(return_data_json);
}